
var slideIndex = 1;

function showSlide(n) {
    var slides = document.querySelectorAll('.slider img');
    if (n > slides.length) { slideIndex = 1 }
    if (n < 1) { slideIndex = slides.length }
    for (var i = 0; i < slides.length; i++) {
        slides[i].style.display = 'none';
    }
    slides[slideIndex - 1].style.display = 'block';
}

function prevSlide() {
    showSlide(slideIndex -= 1);
}

function nextSlide() {
    showSlide(slideIndex += 1);
}

// Con esto, se muestra la primera imagen al cargar la página
showSlide(slideIndex);

